# CripticKey Package

This a custom module that generates a random password for you.

## Installation

You can install this package using pip:

```bash
pip install cryptickey
