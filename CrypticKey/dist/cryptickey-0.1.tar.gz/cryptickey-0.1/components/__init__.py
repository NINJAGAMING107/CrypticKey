from .ck import generate_password, print_password, prompt_user_for_password

prompt_user_for_password()
